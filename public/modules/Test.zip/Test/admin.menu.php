<?php

$submenu = [
	'title'=> AdminFunc::ReturnModule('Test','title'),
	'route'=> route('test.admin.main'),
	'icon'=> '<i class="'.AdminFunc::ReturnModule('Test','icon').'"></i>',
	'permission'=>1,
	'active' => AdminFunc::ReturnModule('Test','active'),
	'path'=>'Test',
	'submenu'=> [
		[
			'title' => AdminFunc::ReturnModule('Test','title'),
			'route' => route('test.admin.main'),
			'icon' => '<i class="fal fa-envelope-open-text"></i>'
		]
	]
];