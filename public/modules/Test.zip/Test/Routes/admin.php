<?php
Route::group(['module'=>'Test','middleware' => ['language','theme:admintheme','CoreMW\checkAdminLogin','CoreMW\CheckMod:Test']], function () {
	Route::prefix('test')->group(function(){
		Route::name('test.admin.')->group(function () {
			Route::get('', 'AdminTestController@main')->name('main');
		});
	});
});
Breadcrumbs::for('admin_test_main', function ($trail) {
    $trail->parent('admin_dashboard');
    $trail->push(AdminFunc::ReturnModule('Test','title'), route('test.admin.main'));
});