<?php

if (AdminFunc::ReturnModule('Test','active')==1) {
	Route::group(['middleware' => ['language','theme:theme','CoreMW\RunWidget','CoreMW\CheckWebMod:Test']], function () {
		if (CFglobal::cfn('moddefault') == 'Test') {
			Route::get('', 'TestController@main')->name('indexhome');
		}
	});
	Route::group(['middleware' => ['language','theme:theme','CoreMW\RunWidget','CoreMW\CheckWebMod:Test']], function () {
		Route::prefix(AdminFunc::GetPrefixMod('Test'))->group(function(){
			Route::name('test.web.')->group(function () {
				Route::get('', 'TestController@main')->name('main');
			});
		});
	});
	Breadcrumbs::for('module_test_main', function ($trail) {
	    $trail->parent('sitehome');
	    $trail->push(AdminFunc::ReturnModule('Test','title'), route('test.web.main'),['background'=>AdminFunc::ReturnModule('Test','bgmod')]);
	});
}