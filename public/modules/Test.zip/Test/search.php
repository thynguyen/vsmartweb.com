<?php
namespace Modules\Test;
use Modules\Test\Entities\Test;
use Modules\Search\ModuleModelSearchAspect;

$searchmodule = $searchResults->registerModel(Test::class, function(ModuleModelSearchAspect $modelSearchAspect) {
       $modelSearchAspect
          ->addSearchableAttribute('title') 
          ->addSearchableAttribute('description') 
          ->addSearchableAttribute('content')
          ->where('active', 1);
});